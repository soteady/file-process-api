package mbbank.steady.sensitivedatascanner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SensitiveDataScannerApplicationTests {

    @Test
    void contextLoads() {
    }

}

package mbbank.steady.sensitivedatascanner;

import java.io.InputStream;
import java.io.IOException;

public interface FileContentReader {
    String read(InputStream inputStream) throws IOException;
    boolean supports(String fileName);
}
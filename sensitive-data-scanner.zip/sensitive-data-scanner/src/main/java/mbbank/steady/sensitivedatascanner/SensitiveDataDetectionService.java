package mbbank.steady.sensitivedatascanner;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.stream.Collectors;

@Service
public class SensitiveDataDetectionService {

    private final List<SensitiveDataRule> rules;

    public SensitiveDataDetectionService() {
        this.rules = new ArrayList<>();
        // Định nghĩa các quy tắc phát hiện thông tin nhạy cảm
        // Sử dụng regex để bao quát các trường hợp có thể có khoảng trắng, dấu gạch ngang, v.v.

        // 1. Thông tin định danh:
        // Số điện thoại (ví dụ: 090-123-4567, +84 90 123 4567)
        rules.add(new SensitiveDataRule("Số điện thoại", "Dữ liệu định danh nhạy cảm", "(0|\\+84|\\(84\\))([\\s.-]?\\d){9,10}"));
        // Số CMND/CCCD (9 hoặc 12 số)
        rules.add(new SensitiveDataRule("Số CMND/CCCD", "Dữ liệu định danh nhạy cảm", "\\b\\d{9}\\b|\\b\\d{12}\\b"));
        // Số hộ chiếu (thường là 1 chữ cái + 7 hoặc 8 số)
        rules.add(new SensitiveDataRule("Số hộ chiếu", "Dữ liệu định danh nhạy cảm", "[A-Z]\\d{7,8}"));
        // Số giấy phép lái xe (ví dụ: A1.123456789)
        rules.add(new SensitiveDataRule("Số giấy phép lái xe", "Dữ liệu định danh nhạy cảm", "[A-Z]\\d{1,2}\\.\\d{9}"));
        // Số biển số xe (ví dụ: 51A-123.45, 29B-12345)
        rules.add(new SensitiveDataRule("Số biển số xe", "Dữ liệu định danh nhạy cảm", "\\b\\d{2}[A-Z]-\\d{3,5}\\b"));
        // Mã số thuế cá nhân (10 hoặc 13 số)
        rules.add(new SensitiveDataRule("Mã số thuế cá nhân", "Dữ liệu định danh nhạy cảm", "\\b\\d{10}(\\s*-\\s*\\d{3})?\\b"));
        // Số bảo hiểm xã hội (10 số)
        rules.add(new SensitiveDataRule("Số bảo hiểm xã hội", "Dữ liệu định danh nhạy cảm", "\\b\\d{10}\\b")); // Có thể trùng với CMND/CCCD, cần tinh chỉnh thêm nếu cần
        // Số thẻ bảo hiểm y tế (ví dụ: DN4010110000007)
        rules.add(new SensitiveDataRule("Số thẻ bảo hiểm y tế", "Dữ liệu định danh nhạy cảm", "[A-Z]{2}\\d{13}"));

        // 2. Mã định danh tổ chức:
        // Mã số thuế tổ chức (10 hoặc 13 số)
        rules.add(new SensitiveDataRule("Mã số thuế tổ chức", "Dữ liệu định danh nhạy cảm", "\\b\\d{10}(\\s*-\\s*\\d{3})?\\b"));

        // 3. Thông tin tài chính:
        // Số tài khoản ngân hàng (thường 9-14 số, tùy ngân hàng)
        rules.add(new SensitiveDataRule("Số tài khoản ngân hàng", "Dữ liệu định danh nhạy cảm", "\\b\\d{9,14}\\b"));
        // Số thẻ (13-19 số, thường 16 số)
        rules.add(new SensitiveDataRule("Số thẻ", "Dữ liệu định danh nhạy cảm", "\\b\\d{13,19}\\b"));
        // Thông tin lương thưởng (các từ khóa liên quan đến lương)
        rules.add(new SensitiveDataRule("Thông tin lương thưởng", "Dữ liệu định danh nhạy cảm", "\\b(lương|thưởng|thu nhập|khoản chi trả)\\b"));

        // 4. Secret Key, API Key, Access Token, session token, ..
        rules.add(new SensitiveDataRule("Secret Key/API Key/Access Token", "Dữ liệu nội bộ nhạy cảm", "\\b(secret_key|api_key|access_token|session_token|auth_token|client_secret)=?[\\w-]{16,64}\\b"));

        // 5. Mã khóa bí mật người dùng (Password)
        rules.add(new SensitiveDataRule("Mật khẩu", "Dữ liệu nội bộ nhạy cảm", "\\b(password|mat_khau|pass|pwd)\\s*[=:]\\s*['\"]?[\\w!@#$%^&*()-+=]{6,30}['\"]?\\b"));

        // Thêm các regex khác nếu cần tinh chỉnh độ chính xác
    }

    public List<ScanResult> scan(String content) {
        List<ScanResult> results = new ArrayList<>();
        if (content == null || content.isEmpty()) {
            return results;
        }

        for (SensitiveDataRule rule : rules) {
            Matcher matcher = rule.getPattern().matcher(content);
            while (matcher.find()) {
                String detectedValue = matcher.group();
                results.add(new ScanResult(
                        rule.getName(),
                        rule.getCategory(),
                        detectedValue,
                        matcher.start(),
                        matcher.end(),
                        "" // Sẽ được điền sau khi highlight
                ));
            }
        }
        return results;
    }

    public String highlightSensitiveData(String originalContent, List<ScanResult> scanResults) {
        if (scanResults.isEmpty()) {
            return originalContent;
        }

        StringBuilder highlightedContent = new StringBuilder(originalContent);
        // Sắp xếp theo vị trí kết thúc giảm dần để tránh ảnh hưởng đến chỉ số khi chèn highlight
        scanResults.sort((r1, r2) -> Integer.compare(r2.getEndIndex(), r1.getEndIndex()));

        String startHighlight = "<<<"; // Có thể dùng thẻ HTML như <span> hoặc markdown như **
        String endHighlight = ">>>";

        for (ScanResult result : scanResults) {
            int start = result.getStartIndex();
            int end = result.getEndIndex();

            // Đảm bảo chỉ số hợp lệ
            if (start >= 0 && end <= highlightedContent.length() && start <= end) {
                highlightedContent.insert(end, endHighlight);
                highlightedContent.insert(start, startHighlight);
                // Cập nhật lại highlightedText cho ScanResult (nếu cần)
                // Lưu ý: Việc lấy lại đoạn text sau khi chèn highlight có thể phức tạp.
                // Ở đây, chúng ta chỉ làm đơn giản là chèn vào StringBuilder.
                // Nếu muốn ScanResult chứa chính xác đoạn đã highlight, bạn cần xử lý phức tạp hơn
                // hoặc lấy đoạn text gốc và thêm highlight vào nó.
                String originalDetected = originalContent.substring(result.getStartIndex(), result.getEndIndex());
                result.setHighlightedText(startHighlight + originalDetected + endHighlight);
            }
        }
        return highlightedContent.toString();
    }
}
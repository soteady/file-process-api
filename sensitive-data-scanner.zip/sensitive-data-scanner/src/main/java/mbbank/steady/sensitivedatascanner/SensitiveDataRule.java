package mbbank.steady.sensitivedatascanner;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.regex.Pattern;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SensitiveDataRule {
    private String name;
    private String category; // e.g., "Dữ liệu định danh nhạy cảm", "Dữ liệu nội bộ nhạy cảm"
    private Pattern pattern;

    public SensitiveDataRule(String name, String category, String regex) {
        this.name = name;
        this.category = category;
        this.pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
    }
}
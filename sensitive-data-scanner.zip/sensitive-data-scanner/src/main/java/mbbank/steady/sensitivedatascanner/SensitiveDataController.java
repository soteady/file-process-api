package mbbank.steady.sensitivedatascanner;

import io.minio.errors.MinioException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/scan")
public class SensitiveDataController {

    private static final Logger logger = LoggerFactory.getLogger(SensitiveDataController.class);

    private final MinioService minioService;
    private final SensitiveDataDetectionService detectionService;
    private final List<FileContentReader> fileContentReaders;

    public SensitiveDataController(MinioService minioService,
                                   SensitiveDataDetectionService detectionService,
                                   List<FileContentReader> fileContentReaders) {
        this.minioService = minioService;
        this.detectionService = detectionService;
        this.fileContentReaders = fileContentReaders;
    }

    @GetMapping("/{objectName}")
    public ResponseEntity<Map<String, Object>> scanFile(@PathVariable String objectName) {
        Map<String, Object> response = new HashMap<>();
        String originalContent = "";
        String newObjectName = ""; // Tên file mới trên MinIO
        String highlightedContent = "";

        try (InputStream minioStream = minioService.getFile(objectName)) {

            // Đọc toàn bộ InputStream vào ByteArrayOutputStream để có thể đọc nhiều lần nếu cần
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            int nRead;
            byte[] data = new byte[1024];
            while ((nRead = minioStream.read(data, 0, data.length)) != -1) {
                buffer.write(data, 0, nRead);
            }
            buffer.flush();

            // Tìm reader phù hợp
            Optional<FileContentReader> reader = fileContentReaders.stream()
                    .filter(r -> r.supports(objectName))
                    .findFirst();

            if (reader.isPresent()) {
                // Đọc nội dung từ file
                originalContent = reader.get().read(new ByteArrayInputStream(buffer.toByteArray()));
                response.put("originalContentSnippet", originalContent.substring(0, Math.min(originalContent.length(), 500)) + "...");

                // Quét thông tin nhạy cảm
                List<ScanResult> scanResults = detectionService.scan(originalContent);

                if (!scanResults.isEmpty()) {
                    response.put("status", "SENSITIVE_DATA_DETECTED");
                    response.put("detectedCount", scanResults.size());
                    response.put("sensitiveData", scanResults);

                    // Highlight thông tin nhạy cảm trong văn bản
                    highlightedContent = detectionService.highlightSensitiveData(originalContent, scanResults);
                    response.put("highlightedContent", highlightedContent); // Thêm vào response

                    logger.warn("Sensitive data detected in file {}: {}", objectName, scanResults);

                    // --- BẮT ĐẦU PHẦN MỚI: UPLOAD FILE ĐÃ HIGHLIGHT LÊN MINIO ---
                    // Tạo tên file mới
                    int lastDotIndex = objectName.lastIndexOf('.');
                    String baseName = (lastDotIndex == -1) ? objectName : objectName.substring(0, lastDotIndex);
                    // Lưu dưới dạng .txt để đơn giản hóa việc highlight
                    newObjectName = baseName + "_checked.txt";

                    // Chuyển đổi highlightedContent thành InputStream
                    InputStream highlightedContentStream = new ByteArrayInputStream(highlightedContent.getBytes(StandardCharsets.UTF_8));

                    // Upload file đã highlight lên MinIO
                    minioService.uploadFile(newObjectName, highlightedContentStream, highlightedContent.getBytes(StandardCharsets.UTF_8).length, "text/plain");
                    response.put("uploadedHighlightedFile", newObjectName);
                    logger.info("Uploaded highlighted content as {} to MinIO.", newObjectName);
                    // --- KẾT THÚC PHẦN MỚI ---

                } else {
                    response.put("status", "NO_SENSITIVE_DATA_FOUND");
                    logger.info("No sensitive data found in file {}", objectName);
                }
            } else {
                response.put("status", "UNSUPPORTED_FILE_TYPE");
                response.put("message", "File type not supported for scanning: " + objectName);
                logger.warn("Unsupported file type for scanning: {}", objectName);
                return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
            }

        } catch (MinioException e) {
            logger.error("MinIO error while processing file {}: {}", objectName, e.getMessage());
            response.put("status", "MINIO_ERROR");
            response.put("message", "Error getting/uploading file from MinIO: " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (IOException e) {
            logger.error("IO error while reading/uploading file {}: {}", objectName, e.getMessage());
            response.put("status", "IO_ERROR");
            response.put("message", "Error reading/uploading file content: " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            logger.error("An unexpected error occurred while processing file {}: {}", objectName, e.getMessage(), e);
            response.put("status", "UNKNOWN_ERROR");
            response.put("message", "An unexpected error occurred: " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
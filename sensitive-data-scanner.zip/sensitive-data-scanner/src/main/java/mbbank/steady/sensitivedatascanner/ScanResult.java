package mbbank.steady.sensitivedatascanner;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ScanResult {
    private String ruleName;
    private String category;
    private String detectedValue;
    private int startIndex;
    private int endIndex;
    private String highlightedText; // To store the text with highlight markers
}
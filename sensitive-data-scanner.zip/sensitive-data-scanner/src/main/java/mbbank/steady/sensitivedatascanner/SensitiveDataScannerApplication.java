package mbbank.steady.sensitivedatascanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SensitiveDataScannerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SensitiveDataScannerApplication.class, args);
    }

}
